var H5P = H5P || {};

H5P.PythonTerminal = (function ($) {
  /**
   * Constructor de la Terminal Python
   */
  function PythonTerminal(params, contentId, contentData) {
    // Asegurar que $ existe
    $ = $ || H5P.jQuery || window.jQuery;
    
    var self = this;
    
    // Heredar de EventDispatcher para xAPI
    H5P.EventDispatcher.call(self);
    
    // Valores por defecto
    const defaults = {
      title: 'Terminal Python Interactiva',
      description: '',
      preloadedCode: '',
      initialCode: '# Escribe tu código Python aquí\nprint("¡Hola, Python!")',
      examples: [],
      showLineNumbers: true,
      theme: 'dark',
      allowInput: true,
      maxOutputLines: 1000,
      enableScoring: false,
      requiredExercises: [],
      passingScore: 70
    };
    
    // Mezclar parámetros
    this.params = {};
    for (var key in defaults) {
      this.params[key] = params && params[key] !== undefined ? params[key] : defaults[key];
    }
    
    this.contentId = contentId;
    this.contentData = contentData || {};
    this.pyodideReady = false;
    this.pyodide = null;
    this.outputLines = [];
    this.currentInput = null;
    this.uploadedFiles = [];
    this.isSending = false; // Flag para prevenir envíos duplicados
    
    // Variables para tracking xAPI
    this.executionHistory = [];
    this.startTime = new Date();
    this.score = 0;
    this.maxScore = this.params.requiredExercises.length || 1;
    this.completedExercises = [];
    
    // Restaurar estado previo si existe
    if (this.contentData.previousState) {
      try {
        var previousState = JSON.parse(this.contentData.previousState);
        this.executionHistory = previousState.executionHistory || [];
        this.completedExercises = previousState.completedExercises || [];
        this.score = previousState.score || 0;
      } catch (e) {
        console.warn('No se pudo restaurar estado previo:', e);
      }
    }
  }
  
  // Heredar de EventDispatcher
  PythonTerminal.prototype = Object.create(H5P.EventDispatcher.prototype);
  PythonTerminal.prototype.constructor = PythonTerminal;

  /**
   * Attach function llamada por H5P framework
   */
  PythonTerminal.prototype.attach = function ($container) {
    const self = this;
    
    // Asegurar que tenemos jQuery
    $ = $ || H5P.jQuery || window.jQuery;
    
    if (!$) {
      console.error('jQuery no disponible');
      $container.html('<div style="padding: 2rem; color: red;">Error: jQuery no está disponible</div>');
      return;
    }
    
    // Crear estructura HTML
    const $wrapper = $('<div>', {
      class: 'h5p-python-terminal theme-' + self.params.theme
    });

    // Contenedor principal
    const $main = $('<div>', { class: 'terminal-main' });

    // Editor de código
    const $editorSection = $('<div>', { class: 'editor-section' });
    
    const $editorHeader = $('<div>', { class: 'editor-header' });
    $editorHeader.append($('<span>', { text: '📝 Editor Python' }));
    
    // Selector de tema para Ace Editor
    const $themeSelector = $('<select>', { class: 'theme-select' });
    $themeSelector.append($('<option>', { value: 'xcode', text: '☀️ Claro', selected: true }));
    $themeSelector.append($('<option>', { value: 'monokai', text: '🌙 Oscuro' }));
    
    $themeSelector.on('change', function() {
      const theme = $(this).val();
      if (self.aceEditor) {
        self.aceEditor.setTheme('ace/theme/' + theme);
      }
    });
    
    $editorHeader.append($themeSelector);
    
    // Botones de ejemplo
    if (self.params.examples && self.params.examples.length > 0) {
      const $examplesDropdown = $('<select>', { class: 'examples-select' });
      $examplesDropdown.append($('<option>', { 
        value: '', 
        text: '💡 Cargar ejemplo...' 
      }));
      
      self.params.examples.forEach(function(example, idx) {
        $examplesDropdown.append($('<option>', {
          value: idx,
          text: example.name
        }));
      });
      
      $examplesDropdown.on('change', function() {
        const idx = $(this).val();
        if (idx !== '') {
          const example = self.params.examples[idx];
          if (self.aceEditor) {
            self.aceEditor.setValue(example.code, -1);
          }
          $(this).val('');
        }
      });
      
      $editorHeader.append($examplesDropdown);
    }
    
    $editorSection.append($editorHeader);

    // Contenedor para Ace Editor
    const $codeEditor = $('<div>', {
      class: 'code-editor',
      id: 'ace-editor-' + self.contentId
    });
    
    $editorSection.append($codeEditor);
    self.$codeEditorElement = $codeEditor[0];

    // Botones de control
    const $controls = $('<div>', { class: 'terminal-controls' });
    
    const $runBtn = $('<button>', {
      class: 'btn btn-run',
      html: '▶️ Ejecutar',
      title: 'Ejecutar código (Ctrl+Enter)'
    }).on('click', function() {
      self.runCode();
    });
    
    const $saveBtn = $('<button>', {
      class: 'btn btn-save',
      html: '💾 Guardar',
      title: 'Guardar y enviar al LRS (Ctrl+S)'
    }).on('click', function() {
      self.saveAndSubmit();
    });
    
    const $clearBtn = $('<button>', {
      class: 'btn btn-clear',
      html: '🗑️ Limpiar',
      title: 'Limpiar consola'
    }).on('click', function() {
      self.clearOutput();
    });
    
    // Botón para subir archivos
    const $fileInput = $('<input>', {
      type: 'file',
      id: 'file-upload-' + self.contentId,
      style: 'display: none;',
      multiple: true
    }).on('change', function(e) {
      self.handleFileUpload(e.target.files);
    });
    
    const $uploadBtn = $('<button>', {
      class: 'btn btn-upload',
      html: '📁 Subir archivo',
      title: 'Subir archivos para usar en Python'
    }).on('click', function() {
      $fileInput.click();
    });

    $controls.append($runBtn, $saveBtn, $clearBtn, $uploadBtn, $fileInput);
    $editorSection.append($controls);

    $main.append($editorSection);

    // Consola de salida
    const $outputSection = $('<div>', { class: 'output-section' });
    
    const $outputHeader = $('<div>', { class: 'output-header' });
    $outputHeader.append($('<span>', { text: '🖥️ Consola' }));
    
    const $statusIndicator = $('<span>', { 
      class: 'status-indicator loading',
      text: '⏳ Cargando Python...'
    });
    self.$statusIndicator = $statusIndicator;
    $outputHeader.append($statusIndicator);
    
    $outputSection.append($outputHeader);

    const $output = $('<div>', {
      class: 'terminal-output',
      html: '<div class="output-line info">🐍 Iniciando Python (Pyodide)...</div>' +
            '<div class="output-line info">⏳ Esto puede tomar unos segundos la primera vez...</div>'
    });
    
    self.$output = $output;
    $outputSection.append($output);

    $main.append($outputSection);
    $wrapper.append($main);

    // Agregar al contenedor
    $container.addClass('h5p-python-terminal-container')
      .html('')
      .append($wrapper);

    // Inicializar Ace Editor después de agregar al DOM
    setTimeout(function() {
      self.initAceEditor();
    }, 100);

    // Cargar Pyodide
    self.loadPyodide();
  };

  /**
   * Inicializar Ace Editor
   */
  PythonTerminal.prototype.initAceEditor = function() {
    const self = this;
    
    if (!self.$codeEditorElement) {
      console.error('Elemento del editor no encontrado');
      return;
    }
    
    // Ace ya está precargado desde preloadedJs
    if (typeof ace !== 'undefined') {
      try {
        self.aceEditor = ace.edit(self.$codeEditorElement);
        self.aceEditor.setTheme('ace/theme/xcode');
        self.aceEditor.session.setMode('ace/mode/python');
        self.aceEditor.setValue(self.params.initialCode, -1);
        
        // Configuraciones del editor
        self.aceEditor.setOptions({
          fontSize: '14px',
          showPrintMargin: false,
          highlightActiveLine: true,
          enableBasicAutocompletion: true,
          enableLiveAutocompletion: false,
          tabSize: 4,
          useSoftTabs: true
        });
        
        // Atajos de teclado
        self.aceEditor.commands.addCommand({
          name: 'run',
          bindKey: { win: 'Ctrl-Enter', mac: 'Cmd-Enter' },
          exec: function() {
            self.runCode(); // Solo ejecutar, no guardar
          }
        });
        
        self.aceEditor.commands.addCommand({
          name: 'save',
          bindKey: { win: 'Ctrl-S', mac: 'Cmd-S' },
          exec: function() {
            self.saveAndSubmit(); // Guardar y enviar al LRS
          }
        });
        
        self.aceEditor.focus();
      } catch (error) {
        console.error('Error al configurar Ace Editor:', error);
      }
    } else {
      console.error('Ace no está disponible');
    }
  };

  /**
   * Cargar Pyodide (Python en WebAssembly)
   */
  PythonTerminal.prototype.loadPyodide = function() {
    const self = this;
    
    // Obtener la ruta base de la librería
    const getLibraryPath = function() {
      if (typeof H5P !== 'undefined' && H5P.getLibraryPath) {
        try {
          return H5P.getLibraryPath('H5P.PythonTerminal-1.1');
        } catch (e) {
          console.warn('H5P.getLibraryPath falló:', e);
        }
      }
      
      const scripts = document.getElementsByTagName('script');
      for (let i = 0; i < scripts.length; i++) {
        const src = scripts[i].src;
        if (src && src.indexOf('python-terminal.js') > -1) {
          return src.substring(0, src.lastIndexOf('/'));
        }
      }
      
      return '/h5p/content/m3/l5/m3_l5_e1/H5P.PythonTerminal-1.1';
    };
    
    // Cargar Pyodide dinámicamente desde archivos locales
    const libraryPath = getLibraryPath();
    const pyodidePath = libraryPath + '/pyodide';
    
    if (typeof loadPyodide === 'undefined') {
      const script = document.createElement('script');
      script.src = pyodidePath + '/pyodide.js';
      script.onload = function() {
        self.initializePyodide(pyodidePath);
      };
      script.onerror = function(error) {
        console.error('Error al cargar Pyodide:', error);
        self.addOutput('❌ Error al cargar Pyodide desde ' + pyodidePath, 'error');
        self.$statusIndicator.removeClass('loading').addClass('error').text('❌ Error');
      };
      document.head.appendChild(script);
    } else {
      self.initializePyodide(pyodidePath);
    }
  };

  /**
   * Inicializar Pyodide
   */
  PythonTerminal.prototype.initializePyodide = function(pyodidePath) {
    const self = this;
    
    // Usar ruta local si se proporciona, sino CDN
    const indexURL = pyodidePath || 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/';
    
    loadPyodide({
      indexURL: indexURL
    }).then(function(pyodide) {
      self.pyodide = pyodide;
      self.pyodideReady = true;
      
      // Configurar stdout y stderr
      pyodide.setStdout({
        batched: function(text) {
          self.addOutput(text, 'stdout');
        }
      });
      
      pyodide.setStderr({
        batched: function(text) {
          self.addOutput(text, 'stderr');
        }
      });
      
      self.$statusIndicator.removeClass('loading').addClass('ready').text('✅ Listo');
      self.addOutput('✅ Python está listo. ¡Puedes ejecutar tu código!', 'success');
      
      // Ejecutar código pre-cargado si existe
      if (self.params.preloadedCode) {
        self.addOutput('⚙️ Ejecutando código de inicialización...', 'info');
        self.runPythonCode(self.params.preloadedCode, false); // No enviar xAPI en código de inicialización
      }
      
    }).catch(function(error) {
      self.addOutput('❌ Error al inicializar Python: ' + error.message, 'error');
      self.$statusIndicator.removeClass('loading').addClass('error').text('❌ Error');
    });
  };

  /**
   * Ejecutar código Python (sin enviar xAPI)
   */
  PythonTerminal.prototype.runCode = function() {
    const self = this;
    
    if (!self.pyodideReady) {
      self.addOutput('⚠️ Python aún no está listo. Por favor espera...', 'warning');
      return;
    }
    
    const code = self.aceEditor ? self.aceEditor.getValue() : '';
    
    if (!code.trim()) {
      self.addOutput('⚠️ No hay código para ejecutar', 'warning');
      return;
    }
    
    self.addOutput('>>> Ejecutando...', 'command');
    self.runPythonCode(code, false); // false = no enviar xAPI
  };

  /**
   * Guardar y enviar al LRS (sin ejecutar)
   */
  PythonTerminal.prototype.saveAndSubmit = function() {
    const self = this;
    
    // Prevenir múltiples envíos simultáneos
    if (self.isSending) {
      return;
    }
    
    const code = self.aceEditor ? self.aceEditor.getValue() : '';
    
    if (!code.trim()) {
      self.addOutput('⚠️ No hay código para guardar', 'warning');
      return;
    }
    
    // Obtener la última ejecución del historial si existe
    const lastExecution = self.executionHistory.length > 0 
      ? self.executionHistory[self.executionHistory.length - 1] 
      : null;
    
    // Validar que exista al menos una ejecución
    if (!lastExecution) {
      self.addOutput('⚠️ Debes ejecutar el código al menos una vez antes de guardar', 'warning');
      return;
    }
    
    self.isSending = true;
    
    // Usar datos de la última ejecución
    const executionSuccess = lastExecution.success;
    const executionError = lastExecution.error;
    const executionResult = lastExecution.result;
    
    // Emitir evento xAPI con el código actual del editor
    self.triggerXAPIAttempt(code, executionSuccess, executionError, executionResult);
    
    self.addOutput('💾 Código guardado y enviado al LRS', 'success');
    
    // Resetear flag después de 1 segundo
    setTimeout(function() {
      self.isSending = false;
    }, 1000);
  };

  /**
   * Ejecutar código Python usando Pyodide
   */
  PythonTerminal.prototype.runPythonCode = function(code, sendXAPI) {
    const self = this;
    
    // sendXAPI es opcional, por defecto false
    sendXAPI = sendXAPI || false;
    
    var executionSuccess = false;
    var executionResult = null;
    var executionError = null;
    
    try {
      // Ejecutar el código
      const result = self.pyodide.runPython(code);
      executionSuccess = true;
      executionResult = result;
      
      // Si hay un resultado (no None), mostrarlo
      if (result !== undefined && result !== null) {
        self.addOutput(String(result), 'result');
      }
      
    } catch (error) {
      // Mostrar error de Python
      executionSuccess = false;
      executionError = error.message;
      self.addOutput(error.message, 'error');
    }
    
    // Registrar ejecución en historial
    var execution = {
      timestamp: new Date().toISOString(),
      code: code,
      success: executionSuccess,
      result: executionResult,
      error: executionError
    };
    
    self.executionHistory.push(execution);
    
    // Solo emitir evento xAPI si se solicita explícitamente
    if (sendXAPI) {
      self.triggerXAPIAttempt(code, executionSuccess, executionError, executionResult);
      
      // Verificar si completó algún ejercicio requerido
      if (self.params.enableScoring && self.params.requiredExercises.length > 0) {
        self.checkExerciseCompletion(code, executionSuccess);
      }
    }
    
    // Guardar estado local (sin enviar xAPI)
    self.saveState();
    
    // Retornar resultado para uso en saveAndSubmit
    return {
      success: executionSuccess,
      result: executionResult,
      error: executionError
    };
  };

  /**
   * Agregar salida a la consola
   */
  PythonTerminal.prototype.addOutput = function(text, type) {
    const self = this;
    
    type = type || 'stdout';
    
    const $line = $('<div>', {
      class: 'output-line ' + type,
      text: text
    });
    
    self.$output.append($line);
    self.outputLines.push($line);
    
    // Limitar número de líneas
    if (self.outputLines.length > self.params.maxOutputLines) {
      self.outputLines.shift().remove();
    }
    
    // Auto-scroll
    self.$output.scrollTop(self.$output[0].scrollHeight);
  };

  /**
   * Limpiar salida
   */
  PythonTerminal.prototype.clearOutput = function() {
    const self = this;
    self.$output.empty();
    self.outputLines = [];
    self.addOutput('🗑️ Consola limpiada', 'info');
  };

  /**
   * Manejar subida de archivos
   */
  PythonTerminal.prototype.handleFileUpload = function(files) {
    const self = this;
    
    if (!self.pyodideReady) {
      self.addOutput('⚠️ Python aún no está listo. Espera a que cargue.', 'warning');
      return;
    }
    
    if (!files || files.length === 0) {
      return;
    }
    
    self.addOutput('📁 Subiendo ' + files.length + ' archivo(s)...', 'info');
    
    // Procesar cada archivo
    Array.from(files).forEach(function(file) {
      const reader = new FileReader();
      
      reader.onload = function(e) {
        try {
          const content = new Uint8Array(e.target.result);
          
          // Escribir archivo en el sistema de archivos virtual de Pyodide
          self.pyodide.FS.writeFile(file.name, content);
          
          // Guardar en la lista de archivos cargados
          self.uploadedFiles.push({
            name: file.name,
            size: file.size,
            type: file.type
          });
          
          self.addOutput('✅ Archivo cargado: ' + file.name + ' (' + self.formatBytes(file.size) + ')', 'success');
          
          // Sugerencia de uso según tipo de archivo
          if (file.name.endsWith('.txt') || file.name.endsWith('.csv')) {
            self.addOutput('   💡 Ejemplo: open("' + file.name + '", "r").read()', 'info');
          } else if (file.name.endsWith('.json')) {
            self.addOutput('   💡 Ejemplo: import json; json.load(open("' + file.name + '"))', 'info');
          } else {
            self.addOutput('   💡 Usar: open("' + file.name + '", "rb") para archivos binarios', 'info');
          }
          
        } catch (error) {
          self.addOutput('❌ Error al cargar ' + file.name + ': ' + error.message, 'error');
        }
      };
      
      reader.onerror = function() {
        self.addOutput('❌ Error al leer ' + file.name, 'error');
      };
      
      // Leer archivo como ArrayBuffer
      reader.readAsArrayBuffer(file);
    });
  };

  /**
   * Formatear bytes a tamaño legible
   */
  PythonTerminal.prototype.formatBytes = function(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  /**
   * Verificar si se completó un ejercicio requerido
   */
  PythonTerminal.prototype.checkExerciseCompletion = function(code, success) {
    const self = this;
    
    if (!success) return;
    
    self.params.requiredExercises.forEach(function(exercise, index) {
      // Si ya está completado, saltar
      if (self.completedExercises.indexOf(index) !== -1) return;
      
      // Verificar si el código contiene la solución esperada
      if (exercise.validation && exercise.validation.type === 'contains') {
        var matches = true;
        exercise.validation.keywords.forEach(function(keyword) {
          if (code.indexOf(keyword) === -1) {
            matches = false;
          }
        });
        
        if (matches) {
          self.completedExercises.push(index);
          self.score++;
          self.addOutput('✅ ¡Ejercicio completado! +1 punto', 'success');
          
          // Emitir evento de progreso
          self.triggerXAPIEvent('progressed', {
            exercise: exercise.name,
            score: self.score,
            maxScore: self.maxScore
          });
        }
      }
    });
    
    // Verificar si completó todos los ejercicios
    if (self.completedExercises.length === self.params.requiredExercises.length) {
      self.triggerXAPICompleted();
    }
  };

  /**
   * Emitir evento xAPI de intento (attempted)
   */
  PythonTerminal.prototype.triggerXAPIAttempt = function(code, success, error, result) {
    const self = this;
    
    // Crear evento xAPI con verbo "attempted"
    var xAPIEvent = self.createXAPIEvent('attempted');
    
    if (xAPIEvent.data && xAPIEvent.data.statement) {
      var duration = new Date() - self.startTime;
      var scorePercentage = Math.round((self.score / self.maxScore) * 100);
      var passed = scorePercentage >= self.params.passingScore;
      
      // Crear objeto result con estructura estándar xAPI
      xAPIEvent.data.statement.result = {
        score: {
          min: 0,
          max: self.maxScore,
          raw: self.score,
          scaled: self.score / self.maxScore
        },
        success: self.params.enableScoring ? passed : (success !== null ? success : false),
        duration: 'PT' + (Math.round(duration / 100) / 10) + 'S',
        response: code,
        completion: self.params.enableScoring 
          ? self.completedExercises.length === self.params.requiredExercises.length 
          : (success !== null ? success : false)
      };
      
      // Agregar extensions en el context (no en result)
      if (xAPIEvent.data.statement.context) {
        xAPIEvent.data.statement.context.extensions = {
          'http://h5p.org/x-api/python-execution': {
            code: code,
            success: success,
            error: error || null,
            result: result !== null && result !== undefined ? String(result) : null,
            timestamp: new Date().toISOString()
          }
        };
      }
    }
    
    self.trigger(xAPIEvent);
  };

  /**
   * Emitir evento xAPI
   */
  PythonTerminal.prototype.triggerXAPIEvent = function(verb, data) {
    const self = this;
    
    // Crear evento xAPI usando H5P.XAPIEvent
    var xAPIEvent = self.createXAPIEvent(verb);
    
    // Agregar datos específicos
    if (data && xAPIEvent.data && xAPIEvent.data.statement) {
      xAPIEvent.data.statement.result = xAPIEvent.data.statement.result || {};
      xAPIEvent.data.statement.result.extensions = {
        'http://h5p.org/x-api/python-execution': data
      };
    }
    
    self.trigger(xAPIEvent);
  };
  
  /**
   * Crear evento xAPI básico
   */
  PythonTerminal.prototype.createXAPIEvent = function(verb) {
    var self = this;
    var xAPIEvent = new H5P.XAPIEvent();
    xAPIEvent.setVerb(verb);
    xAPIEvent.setActor();
    xAPIEvent.setObject(this);
    
    if (self.contentId) {
      xAPIEvent.setContext(self.contentId);
    }
    
    // Asegurar que el context incluya la información de la librería
    if (xAPIEvent.data && xAPIEvent.data.statement) {
      xAPIEvent.data.statement.context = xAPIEvent.data.statement.context || {};
      xAPIEvent.data.statement.context.contextActivities = xAPIEvent.data.statement.context.contextActivities || {};
      xAPIEvent.data.statement.context.contextActivities.category = xAPIEvent.data.statement.context.contextActivities.category || [];
      
      // Agregar identificador de la librería PythonTerminal
      var categoryArray = Array.isArray(xAPIEvent.data.statement.context.contextActivities.category) 
        ? xAPIEvent.data.statement.context.contextActivities.category 
        : [xAPIEvent.data.statement.context.contextActivities.category];
      
      // Agregar solo si no existe ya
      var hasPythonTerminal = categoryArray.some(function(cat) {
        return cat && cat.id && cat.id.includes('H5P.PythonTerminal');
      });
      
      if (!hasPythonTerminal) {
        categoryArray.push({
          id: 'http://h5p.org/libraries/H5P.PythonTerminal-1.1',
          objectType: 'Activity',
          definition: {
            name: {
              'en-US': 'H5P.PythonTerminal',
              'es': 'Terminal Python H5P'
            },
            description: {
              'en-US': 'Python Terminal',
              'es': 'Terminal Python Interactiva'
            }
          }
        });
      }
      
      xAPIEvent.data.statement.context.contextActivities.category = categoryArray;
    }
    
    return xAPIEvent;
  };

  /**
   * Emitir evento de completado
   */
  PythonTerminal.prototype.triggerXAPICompleted = function() {
    const self = this;
    
    var duration = new Date() - self.startTime;
    var scorePercentage = Math.round((self.score / self.maxScore) * 100);
    var passed = scorePercentage >= self.params.passingScore;
    
    var xAPIEvent = self.createXAPIEvent('completed');
    
    // Configurar resultado con puntuación
    if (xAPIEvent.data && xAPIEvent.data.statement) {
      xAPIEvent.data.statement.result = {
        score: {
          min: 0,
          max: self.maxScore,
          raw: self.score,
          scaled: self.score / self.maxScore
        },
        completion: true,
        success: passed,
        duration: 'PT' + Math.round(duration / 1000) + 'S'
      };
    }
    
    self.trigger(xAPIEvent);
    
    // Mostrar mensaje de finalización
    self.addOutput('', 'info');
    self.addOutput('🎉 ¡Has completado todos los ejercicios!', 'success');
    self.addOutput('📊 Puntuación: ' + self.score + '/' + self.maxScore + ' (' + scorePercentage + '%)', 'success');
    self.addOutput(passed ? '✅ ¡Aprobado!' : '❌ Necesitas practicar más', passed ? 'success' : 'warning');
  };

  /**
   * Obtener puntuación actual
   */
  PythonTerminal.prototype.getScore = function() {
    return this.score;
  };

  /**
   * Obtener puntuación máxima
   */
  PythonTerminal.prototype.getMaxScore = function() {
    return this.maxScore;
  };

  /**
   * Obtener respuesta actual (para xAPI)
   */
  PythonTerminal.prototype.getCurrentState = function() {
    const self = this;
    
    return JSON.stringify({
      executionHistory: self.executionHistory,
      completedExercises: self.completedExercises,
      score: self.score,
      codeInEditor: self.aceEditor ? self.aceEditor.getValue() : ''
    });
  };

  /**
   * Guardar estado
   */
  PythonTerminal.prototype.saveState = function() {
    const self = this;
    
    if (typeof self.setActivityStarted === 'function') {
      self.setActivityStarted();
    }
    
    // Emitir evento de guardado
    self.trigger('resize');
  };

  /**
   * Obtener xAPI data
   */
  PythonTerminal.prototype.getXAPIData = function() {
    const self = this;
    
    var xAPIEvent = self.createXAPIEvent('answered');
    
    // Agregar resultado si hay scoring
    if (self.params.enableScoring && xAPIEvent.data && xAPIEvent.data.statement) {
      var duration = new Date() - self.startTime;
      var scorePercentage = Math.round((self.score / self.maxScore) * 100);
      var passed = scorePercentage >= self.params.passingScore;
      
      xAPIEvent.data.statement.result = {
        score: {
          min: 0,
          max: self.maxScore,
          raw: self.score,
          scaled: self.score / self.maxScore
        },
        completion: self.completedExercises.length === self.params.requiredExercises.length,
        success: passed,
        duration: 'PT' + Math.round(duration / 1000) + 'S'
      };
    }
    
    return {
      statement: xAPIEvent.data.statement,
      children: []
    };
  };

  return PythonTerminal;
})(H5P.jQuery);

